from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Response
from fastapi.responses import Response as RawResponse

from .. import database as db
from ..config import get_settings
from ..models import CATEGORIES, STATUSES, TEMPLATE_INFO
from ..schemas import ProjectCreate
from ..services import orchestrator as orch

router = APIRouter(prefix="/api")


def ok(data, status_code: int = 200):
    from fastapi.responses import JSONResponse
    return JSONResponse({"success": True, "data": data, "error": None}, status_code=status_code)


def _translate(exc: Exception) -> HTTPException:
    if isinstance(exc, orch.NotFound):
        return HTTPException(404, "Project not found.")
    if isinstance(exc, orch.Conflict):
        return HTTPException(409, str(exc))
    raise exc


@router.post("/projects", status_code=201)
def create_project(payload: ProjectCreate):
    return ok(orch.create_project(payload), 201)


@router.get("/projects")
def list_projects(category: Optional[str] = None, status: Optional[str] = None,
                  search: Optional[str] = Query(None, max_length=100), include_demo: bool = True):
    if category and category not in CATEGORIES:
        raise HTTPException(422, f"Unknown category '{category}'.")
    if status and status not in STATUSES:
        raise HTTPException(422, f"Unknown status '{status}'.")
    with db.connect() as conn:
        return ok(db.list_projects(conn, category=category, status=status, search=search, include_demo=include_demo))


@router.get("/projects/{project_id}")
def get_project(project_id: str):
    try:
        return ok(orch.get_project(project_id))
    except Exception as exc:
        raise _translate(exc)


@router.post("/projects/{project_id}/generate")
def generate(project_id: str):
    try:
        return ok(orch.generate_project(project_id))
    except Exception as exc:
        raise _translate(exc)


@router.get("/projects/{project_id}/download")
def download(project_id: str):
    try:
        filename, data = orch.build_download(project_id)
    except Exception as exc:
        raise _translate(exc)
    return RawResponse(data, media_type="application/zip",
                       headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.delete("/projects/{project_id}")
def delete(project_id: str):
    try:
        orch.delete_project(project_id)
    except Exception as exc:
        raise _translate(exc)
    return ok({"deleted": project_id})


@router.get("/analytics")
def analytics(include_demo: bool = False):
    return ok(orch.analytics(include_demo))


@router.get("/templates")
def templates():
    return ok([{"key": k, "title": t, "description": d} for k, (t, d) in TEMPLATE_INFO.items()])


@router.get("/settings")
def settings():
    s = get_settings()  # non-secret values only; paths shown relative-safe
    return ok({"generation_dir": s.generation_dir.name, "max_request_bytes": s.max_request_bytes,
               "run_generated_tests": s.run_generated_tests, "generated_tests_timeout": s.generated_tests_timeout,
               "integrations": {"authentication": "not implemented", "payments": "not implemented",
                                "ai_provider": "not configured", "cloud_deployment": "not implemented"}})
