"""Pydantic request validation."""
import re
from typing import Optional

from pydantic import BaseModel, Field, field_validator

from .models import CATEGORIES

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9 _-]{2,59}$")


class ProjectCreate(BaseModel):
    name: str = Field(..., description="3-60 chars: letters, digits, space, '-' or '_'; must start with a letter")
    category: str
    description: str = Field("", max_length=1000)
    features: list[str] = Field(default_factory=list, max_length=20)

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        v = v.strip()
        if not NAME_RE.match(v):
            raise ValueError("Name must be 3-60 characters, start with a letter and use only letters, digits, spaces, '-' or '_'.")
        return v

    @field_validator("category")
    @classmethod
    def _category(cls, v: str) -> str:
        if v not in CATEGORIES:
            raise ValueError(f"Category must be one of: {', '.join(CATEGORIES)}.")
        return v

    @field_validator("features")
    @classmethod
    def _features(cls, v: list[str]) -> list[str]:
        out = []
        for f in v:
            f = f.strip()
            if not f or len(f) > 80:
                raise ValueError("Each feature must be 1-80 characters.")
            out.append(f)
        return out
