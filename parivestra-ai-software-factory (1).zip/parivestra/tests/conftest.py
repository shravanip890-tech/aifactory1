import os
import tempfile

_tmp = tempfile.mkdtemp(prefix="parivestra-tests-")
os.environ["GENERATION_DIR"] = os.path.join(_tmp, "generated")
os.environ["DB_PATH"] = os.path.join(_tmp, "factory.db")
os.environ["RUN_GENERATED_TESTS"] = "false"

import shutil  # noqa: E402
from pathlib import Path  # noqa: E402

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402


@pytest.fixture(autouse=True)
def clean_state():
    for p in (os.environ["DB_PATH"],):
        Path(p).unlink(missing_ok=True)
    shutil.rmtree(os.environ["GENERATION_DIR"], ignore_errors=True)
    yield


@pytest.fixture()
def client():
    from backend.main import create_app
    return TestClient(create_app(), raise_server_exceptions=False)


@pytest.fixture()
def make(client):
    def _make(name="Test Billing", category="Billing", **extra):
        r = client.post("/api/projects", json={"name": name, "category": category, **extra})
        assert r.status_code == 201, r.text
        return r.json()["data"]
    return _make
