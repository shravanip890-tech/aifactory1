"""Dashboard integration: real uvicorn server + Streamlit's AppTest (no browser)."""
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def server():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    env = {**os.environ, "GENERATION_DIR": os.environ["GENERATION_DIR"] + "-ui", "DB_PATH": os.environ["DB_PATH"] + "-ui.db"}
    proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "backend.main:app", "--port", str(port), "--log-level", "warning"],
                            cwd=ROOT, env=env)
    for _ in range(50):
        try:
            if httpx.get(f"http://127.0.0.1:{port}/health", timeout=1).status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.2)
    else:
        proc.kill(); pytest.fail("server did not start")
    os.environ["API_BASE_URL"] = f"http://127.0.0.1:{port}"
    yield port
    proc.terminate(); proc.wait(5)


def app():
    return AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()


def test_home_renders_with_empty_state(server):
    at = app()
    assert not at.exception
    assert any("Build your" in m.value for m in at.markdown)
    assert any("No projects yet" in m.value for m in at.markdown)
    assert [b.label for b in at.button].count("Create Project") == 4


def test_create_project_button_navigates_and_generates(server):
    at = app()
    next(b for b in at.button if b.key == "create_Billing").click().run()
    assert at.session_state["page"] == "Generate Project" and at.selectbox(key="gen_category").value == "Billing"
    at.text_input[0].set_value("Dashboard Billing Test")
    at.button[-1].click().run()  # form submit
    assert not at.exception and not at.error
    assert any("python_syntax" in w.value for w in at.markdown), "checks should be displayed"
    projects = httpx.get(os.environ["API_BASE_URL"] + "/api/projects").json()["data"]
    assert projects[0]["name"] == "Dashboard Billing Test" and projects[0]["status"] == "Completed"


def test_invalid_name_shows_api_error(server):
    at = app()
    at.session_state["page"] = "Generate Project"
    at.run()
    at.text_input[0].set_value("x")
    at.button[-1].click().run()
    assert at.error and "Name must be" in at.error[0].value


def test_all_pages_render_without_exceptions(server):
    for page in ["Home", "Generate Project", "My Projects", "Analytics", "Documentation", "Settings"]:
        at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60)
        at.session_state["page"] = page
        at.run()
        assert not at.exception, page


def test_unreachable_backend_message(monkeypatch):
    monkeypatch.setenv("API_BASE_URL", "http://127.0.0.1:9")
    monkeypatch.setenv("AUTOSTART_BACKEND", "false")
    at = app()
    assert at.error and "not reachable" in at.error[0].value


def test_dashboard_starts_backend_by_itself(monkeypatch):
    from ui import api_client
    monkeypatch.setenv("API_BASE_URL", "http://127.0.0.1:9")  # nothing there
    monkeypatch.setenv("AUTOSTART_BACKEND", "true")
    monkeypatch.setenv("GENERATION_DIR", os.environ["GENERATION_DIR"] + "-auto")
    monkeypatch.setenv("DB_PATH", os.environ["DB_PATH"] + "-auto.db")
    try:
        at = app()
        assert not at.exception and not at.error
        assert api_client.health() and api_client.base_url() != "http://127.0.0.1:9"
    finally:
        api_client.stop_backend()
