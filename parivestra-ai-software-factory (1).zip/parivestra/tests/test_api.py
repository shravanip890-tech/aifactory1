import io
import os
import sqlite3
import zipfile
from pathlib import Path

import pytest

from backend import database as db
from backend.services import generation_service as gen
from backend.services import orchestrator as orch


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["data"]["status"] == "ok"


def test_create_and_retrieve(client, make):
    p = make(description="demo", features=["a"])
    assert p["status"] == "Queued" and p["template"] == "billing" and len(p["id"]) == 12
    got = client.get(f"/api/projects/{p['id']}").json()["data"]
    assert got["name"] == "Test Billing" and got["features"] == ["a"] and "output_dir" not in got
    assert len(client.get("/api/projects").json()["data"]) == 1
    assert client.get("/api/projects", params={"search": "billing"}).json()["data"][0]["id"] == p["id"]
    assert client.get("/api/projects", params={"category": "CRM"}).json()["data"] == []


def test_sqlite_persistence(client, make):
    p = make()
    raw = sqlite3.connect(os.environ["DB_PATH"])
    assert raw.execute("SELECT name FROM projects WHERE id=?", (p["id"],)).fetchone()[0] == "Test Billing"
    assert raw.execute("SELECT COUNT(*) FROM events WHERE project_id=?", (p["id"],)).fetchone()[0] == 1
    raw.close()
    from backend.main import create_app  # "restart"
    from fastapi.testclient import TestClient
    assert TestClient(create_app()).get(f"/api/projects/{p['id']}").status_code == 200


@pytest.mark.parametrize("category,template", [("Billing", "billing"), ("GST", "gst"), ("Inventory", "inventory"),
                                               ("CRM", "crm"), ("Custom", "custom")])
def test_template_selection_and_real_files(client, make, category, template):
    p = make(name=f"My {category} App", category=category)
    assert p["template"] == template
    r = client.post(f"/api/projects/{p['id']}/generate")
    assert r.status_code == 200, r.text
    d = r.json()["data"]
    assert d["status"] == "Completed" and d["error"] is None
    paths = {f["path"] for f in d["files"]}
    assert {"README.md", "requirements.txt", "app/main.py", "tests/test_app.py"} <= paths
    out = gen.safe_output_dir(p["id"], p["slug"])
    assert out.is_dir() and (out / "app/main.py").stat().st_size > 100
    assert f"My {category} App" in (out / "README.md").read_text()
    assert {c["name"]: c["status"] for c in d["checks"]}["python_syntax"] == "passed"
    assert {c["name"]: c["status"] for c in d["checks"]}["generated_tests"] == "skipped"  # honest: not run


def test_gst_readme_has_disclaimer(client, make):
    p = make(name="Tax App", category="GST")
    client.post(f"/api/projects/{p['id']}/generate")
    text = (gen.safe_output_dir(p["id"], p["slug"]) / "README.md").read_text()
    assert "**not** verified for legal or tax compliance" in " ".join(text.split())


def test_custom_features_and_unsupported(client, make):
    p = make(name="Custom One", category="Custom", features=["notes", "Mobile App"])
    d = client.post(f"/api/projects/{p['id']}/generate").json()["data"]
    paths = {f["path"] for f in d["files"]}
    assert "app/notes.py" in paths and "app/csv_export.py" not in paths and "NOT_IMPLEMENTED.md" in paths
    out = gen.safe_output_dir(p["id"], p["slug"])
    assert "Mobile App" in (out / "NOT_IMPLEMENTED.md").read_text()
    assert "notes_router" in (out / "app/main.py").read_text()


def test_file_verification_detects_problems(tmp_path):
    (tmp_path / "app").mkdir()
    (tmp_path / "app/main.py").write_text("def broken(:\n")
    (tmp_path / "README.md").write_text("")
    files = gen.collect_files(tmp_path)
    status = {c["name"]: c["status"] for c in gen.verify_files(tmp_path, files)}
    assert status["required_files"] == status["non_empty"] == status["python_syntax"] == "failed"


def test_zip_download(client, make):
    p = make(name="Zip Me", category="Inventory")
    assert client.get(f"/api/projects/{p['id']}/download").status_code == 409  # not generated yet
    client.post(f"/api/projects/{p['id']}/generate")
    r = client.get(f"/api/projects/{p['id']}/download")
    assert r.status_code == 200 and r.headers["content-type"] == "application/zip"
    names = zipfile.ZipFile(io.BytesIO(r.content)).namelist()
    assert any(n.endswith("/app/main.py") for n in names) and all(".." not in n and not n.startswith("/") for n in names)
    assert client.get("/api/projects/doesnotexist/download").status_code == 404


def test_invalid_input(client):
    for bad in [{"name": "ab", "category": "Billing"}, {"name": "../etc/passwd", "category": "Billing"},
                {"name": "Good Name", "category": "Nope"}, {"name": "Good Name"},
                {"name": "Good Name", "category": "CRM", "features": [""]},
                {"name": "Good Name", "category": "CRM", "description": "x" * 1001}]:
        r = client.post("/api/projects", json=bad)
        assert r.status_code == 422 and r.json()["success"] is False and r.json()["error"]["code"] == "validation_error"
    assert client.post("/api/projects", content=b"not json", headers={"content-type": "application/json"}).status_code == 422
    assert client.get("/api/projects", params={"status": "Bogus"}).status_code == 422
    assert client.get("/api/projects/nope").status_code == 404
    assert client.post("/api/projects/nope/generate").status_code == 404


def test_request_size_limit(client):
    r = client.post("/api/projects", json={"name": "Big One", "category": "CRM", "description": "x" * 100},
                    headers={"content-length": "999999"})
    assert r.status_code == 413


def test_failed_generation_is_honest(client, make, monkeypatch):
    p = make()
    def boom(*a, **k):
        raise RuntimeError("template exploded")
    monkeypatch.setattr(gen, "render_template", boom)
    r = client.post(f"/api/projects/{p['id']}/generate")
    d = r.json()["data"]
    assert d["status"] == "Failed" and "template exploded" in d["error"] and d["files"] == [] and d["file_count"] == 0
    assert client.get(f"/api/projects/{p['id']}/download").status_code == 409
    monkeypatch.undo()  # retry succeeds
    assert client.post(f"/api/projects/{p['id']}/generate").json()["data"]["status"] == "Completed"


def test_failed_verification_marks_failed(client, make, monkeypatch):
    p = make()
    monkeypatch.setattr(gen, "verify_files", lambda d, f: [{"name": "python_syntax", "status": "failed", "detail": "forced"}])
    d = client.post(f"/api/projects/{p['id']}/generate").json()["data"]
    assert d["status"] == "Failed" and "forced" in d["error"]


def test_missing_template_fails(client, make, monkeypatch, tmp_path):
    p = make()
    monkeypatch.setenv("TEMPLATES_DIR", str(tmp_path))
    d = client.post(f"/api/projects/{p['id']}/generate").json()["data"]
    assert d["status"] == "Failed" and "not available" in d["error"]


def test_running_project_conflicts(client, make):
    p = make()
    with db.connect() as conn:
        db.update_project(conn, p["id"], status="Running")
    assert client.post(f"/api/projects/{p['id']}/generate").status_code == 409
    assert client.delete(f"/api/projects/{p['id']}").status_code == 409


def test_generated_tests_run_when_enabled(client, make, monkeypatch):
    monkeypatch.setenv("RUN_GENERATED_TESTS", "true")
    p = make(name="Runs Tests", category="CRM")
    d = client.post(f"/api/projects/{p['id']}/generate").json()["data"]
    t = {c["name"]: c for c in d["checks"]}["generated_tests"]
    assert d["status"] == "Completed" and t["status"] == "passed" and "passed" in t["detail"]


def test_analytics_calculations(client, make, monkeypatch):
    a = make(name="Alpha One"); b = make(name="Beta Two", category="CRM"); make(name="Gamma Three", category="GST")
    client.post(f"/api/projects/{a['id']}/generate")
    monkeypatch.setattr(gen, "render_template", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("x")))
    client.post(f"/api/projects/{b['id']}/generate")
    d = client.get("/api/analytics").json()["data"]
    assert d["total_projects"] == 3
    assert d["by_status"] == {"Queued": 1, "Running": 0, "Completed": 1, "Failed": 1}
    assert d["by_category"]["CRM"] == 1 and d["success_rate"] == 50.0
    assert d["total_files_generated"] == 6 and d["avg_generation_ms"] is not None
    assert d["recent_activity"][0]["kind"] == "failed"


def test_analytics_empty_and_demo_separation(client):
    d = client.get("/api/analytics").json()["data"]
    assert d["total_projects"] == 0 and d["success_rate"] is None
    from backend.seed import seed
    assert seed() == 4 and seed() == 0  # idempotent
    assert client.get("/api/analytics").json()["data"]["total_projects"] == 0
    both = client.get("/api/analytics", params={"include_demo": True}).json()["data"]
    assert both["total_projects"] == 4 and both["by_status"]["Completed"] == 0
    assert all(p["is_demo"] for p in client.get("/api/projects").json()["data"])


def test_safe_delete_and_paths(client, make, tmp_path):
    p = make(name="Delete Me")
    client.post(f"/api/projects/{p['id']}/generate")
    out = gen.safe_output_dir(p["id"], p["slug"])
    sibling = out.parent / "unrelated-user-dir"
    sibling.mkdir(); (sibling / "keep.txt").write_text("keep")
    assert client.delete(f"/api/projects/{p['id']}").status_code == 200
    assert not out.exists() and (sibling / "keep.txt").exists()
    assert client.get(f"/api/projects/{p['id']}").status_code == 404
    assert client.delete(f"/api/projects/{p['id']}").status_code == 404


@pytest.mark.parametrize("pid,slug", [("../../etc/pass", "x"), ("abcdef123456", "../../x"), ("abcdef123456", "a/b"),
                                      ("ABCDEF123456", "ok"), ("short", "ok")])
def test_unsafe_identifiers_rejected(pid, slug):
    with pytest.raises(gen.GenerationError):
        gen.safe_output_dir(pid, slug)


def test_path_helpers_block_escape(tmp_path):
    base = Path(os.environ["GENERATION_DIR"])
    base.mkdir(parents=True, exist_ok=True)
    with pytest.raises(gen.GenerationError):
        gen.ensure_inside(base / ".." / "outside", base)
    with pytest.raises(gen.GenerationError):
        gen.remove_output(tmp_path)  # outside generation dir: refused
    with pytest.raises(gen.GenerationError):
        gen.remove_output(base)  # the root itself: refused
    assert tmp_path.exists()


def test_unhandled_error_hides_details(client, monkeypatch):
    monkeypatch.setattr(orch, "analytics", lambda include_demo=False: 1 / 0)
    r = client.get("/api/analytics")
    assert r.status_code == 500 and "division" not in r.text and r.json()["error"]["code"] == "internal_error"


def test_settings_endpoint_exposes_no_secrets(client):
    d = client.get("/api/settings").json()["data"]
    assert "db_path" not in d and "/" not in d["generation_dir"]
    assert d["integrations"]["payments"] == "not implemented"


def test_docs_available(client):
    assert client.get("/docs").status_code == 200 and client.get("/openapi.json").status_code == 200
