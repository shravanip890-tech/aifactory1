"""Parivestra AI Software Factory - Streamlit dashboard (talks to the FastAPI backend)."""
import base64
from pathlib import Path

import streamlit as st

from ui import api_client as api
from ui import dashboard as d
from ui import styles

st.set_page_config(page_title="Parivestra AI Software Factory", page_icon="🌸", layout="wide")
styles.apply()

LOGO = Path(__file__).parent / "ui" / "assets" / "logo.png"
st.session_state.setdefault("page", "Home")
with st.sidebar:
    if LOGO.exists():
        b64 = base64.b64encode(LOGO.read_bytes()).decode()
        st.markdown(f'<div class="pv-logo"><img src="data:image/png;base64,{b64}" alt="Parivestra"></div>', unsafe_allow_html=True)
    st.markdown('<div class="pv-brand"><i>&#9650;</i><span>AI Software<br>Factory</span></div>', unsafe_allow_html=True)
    st.radio("Navigation", d.PAGES, key="page", label_visibility="collapsed",
             format_func=lambda p: f":material/{d.NAV_ICONS[p]}: {p}")
    st.markdown('<div style="height:34vh"></div><div class="pv-guest"><span class="pv-avatar">G</span>'
                '<span><b>Guest</b><br><small>Local mode</small></span></div>', unsafe_allow_html=True)

with st.spinner("Starting backend..."):
    ready = api.ensure_backend()
if not ready:
    st.error(f"The backend API is not reachable at {api.base_url()} and could not be started automatically. "
             "See data/api.log, or start it yourself: `uvicorn backend.main:app --port 8000`")
    st.stop()

{"Home": d.home, "Generate Project": d.generate_page, "My Projects": d.projects_page,
 "Analytics": d.analytics_page, "Documentation": d.docs_page, "Settings": d.settings_page}[st.session_state["page"]]()
