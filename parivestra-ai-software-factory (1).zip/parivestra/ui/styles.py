"""Parivestra theme matched to the reference design (mint frame, white workspace, pastel cards)."""
import streamlit as st

CSS = """
<style>
:root { --mint:#B6E8D7; --rose:#E84D91; --plum:#2D2140; --blush:#FFEAF1; --pink:#FFD6E6; --peach:#FFE5CF;
        --lav:#E6DCFF; --green:#C8F0E0; --panel:#F8F3F8; --muted:#7B6E8A; }
.stApp { background: var(--mint); color: var(--plum); }
header[data-testid="stHeader"] { background: transparent; }
.block-container { background:#FEFCFD; border-radius:34px; margin:.6rem auto; padding:1.6rem 1.8rem !important;
  max-width:1560px; box-shadow:0 10px 40px rgba(45,33,64,.10); }
h1,h2,h3,h4 { color: var(--plum); }

/* sidebar */
[data-testid="stSidebar"] { background: var(--blush); border-radius:0 30px 30px 0; }
[data-testid="stSidebar"] * { color: var(--plum); }
.pv-logo { background:#fff; border-radius:20px; padding:.5rem; box-shadow:0 2px 10px rgba(45,33,64,.08); margin-bottom:.9rem; }
.pv-logo img { width:100%; display:block; }
.pv-brand { display:flex; align-items:center; gap:.7rem; font-weight:800; font-size:1.15rem; line-height:1.1; margin:.4rem 0 1rem; }
.pv-brand i { width:38px; height:38px; border-radius:12px; background:var(--plum); display:inline-flex; align-items:center; justify-content:center; font-style:normal; color:var(--rose); }
.st-key-page [role="radiogroup"] { gap:.2rem; }
.st-key-page label { padding:.7rem .9rem; border-radius:16px; width:100%; margin:0; cursor:pointer; }
.st-key-page label > div:first-child { display:none; }
.st-key-page label:has(input:checked) { background:var(--pink); }
.st-key-page label:has(input:checked) * { color:var(--rose) !important; font-weight:700; }
.pv-guest { background:#fff; border-radius:20px; padding:.8rem 1rem; display:flex; align-items:center; gap:.7rem; box-shadow:0 2px 10px rgba(45,33,64,.08); }
.pv-avatar { width:38px; height:38px; border-radius:50%; background:var(--lav); display:inline-flex; align-items:center; justify-content:center; font-weight:800; flex:none; }

/* hero */
.pv-hero { font-size:4.1rem; font-weight:800; line-height:.98; letter-spacing:-.03em; margin:0; }
.pv-sub { color:var(--muted); font-size:1.1rem; margin:.9rem 0 1.2rem; }
.pv-illus { text-align:right; }

/* filter pills */
.st-key-home_filter [role="radiogroup"] { gap:.5rem; flex-wrap:wrap; }
.st-key-home_filter label { background:#fff; border:1px solid #E5DDE9; border-radius:999px; padding:.35rem 1.1rem; margin:0; cursor:pointer; }
.st-key-home_filter label > div:first-child { display:none; }
.st-key-home_filter label:has(input:checked) { background:var(--plum); border-color:var(--plum); }
.st-key-home_filter label:has(input:checked) * { color:#fff !important; }
.pv-section { font-size:1.35rem; font-weight:800; margin:1rem 0 .6rem; }

/* template cards */
[class*="st-key-card_"] { border-radius:30px; padding:1.3rem 1.4rem 1.2rem; min-height:235px; margin-bottom:.4rem; }
.st-key-card_Billing { background:var(--pink); } .st-key-card_GST { background:var(--peach); }
.st-key-card_Inventory { background:var(--lav); } .st-key-card_CRM { background:var(--green); }
.st-key-card_Custom { background:#EFEAF4; }
.pv-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; }
.pv-cat { display:flex; align-items:center; gap:.6rem; font-size:.95rem; }
.pv-ico { width:38px; height:38px; background:#fff; border-radius:12px; display:inline-flex; align-items:center; justify-content:center; font-weight:800; }
.pv-tag { background:#fff8; border-radius:999px; padding:.2rem .75rem; font-size:.78rem; font-weight:700; }
.pv-ct { font-size:1.55rem; font-weight:800; margin:0 0 .3rem; }
.pv-cd { font-size:1.02rem; color:#4a3d5c; margin:0 0 .9rem; }
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button, .stLinkButton > a {
  border-radius:999px; border:0; background:var(--rose); color:#fff !important; font-weight:700; padding:.5rem 1.4rem; }
.stButton > button:hover, .stDownloadButton > button:hover, .stFormSubmitButton > button:hover { background:#c93a7a; color:#fff; }

/* right overview panel */
.st-key-overview { background:var(--panel); border-radius:30px; padding:1.3rem 1.2rem; }
.pv-wel { display:flex; justify-content:space-between; align-items:flex-start; }
.pv-wel b { font-size:1.35rem; } .pv-wel small { color:var(--muted); }
.pv-h { font-size:1.15rem; font-weight:800; margin:1.1rem 0 .6rem; display:flex; align-items:center; gap:.5rem; }
.pv-inc { background:var(--lav); border-radius:999px; font-size:.7rem; padding:.1rem .6rem; font-weight:700; }
.pv-tiles { display:flex; gap:.6rem; }
.pv-tile { flex:1; border-radius:18px; padding:.8rem .9rem; } .pv-tile b { font-size:1.9rem; display:block; line-height:1.1; }
.pv-tile small { color:#5f5270; }
.pv-bars { display:flex; align-items:flex-end; gap:.55rem; height:130px; margin-top:.4rem; }
.pv-bar { flex:1; display:flex; flex-direction:column; justify-content:flex-end; align-items:stretch; height:100%; }
.pv-bar div { border-radius:10px; min-height:0; } .pv-bar .d { background:var(--lav); } .pv-bar .r { background:var(--rose); } .pv-bar .z { background:#EDE7F2; height:6px; }
.pv-days { display:flex; gap:.55rem; color:var(--muted); font-size:.78rem; margin-top:.3rem; } .pv-days span { flex:1; text-align:center; }
.pv-note { color:var(--muted); font-size:.8rem; margin-top:.5rem; }
.pv-proj { background:#fff; border:1px solid #EFE7F1; border-radius:18px; padding:.8rem .95rem; margin-bottom:.6rem; }
.pv-proj .t { display:flex; justify-content:space-between; gap:.5rem; align-items:center; font-weight:800; }
.pv-proj small { color:var(--muted); } .pv-bg { background:#F1E9F1; border-radius:99px; height:8px; margin:.5rem 0 .25rem; overflow:hidden; } .pv-bg i { display:block; height:100%; background:var(--rose); border-radius:99px; }
.pv-badge { display:inline-block; padding:.12rem .7rem; border-radius:999px; font-size:.75rem; font-weight:700; white-space:nowrap; }
.pv-Queued{background:var(--lav)} .pv-Running{background:var(--pink);color:var(--rose)} .pv-Completed{background:var(--green)} .pv-Failed{background:#FFC9D9}
.pv-demo { background:var(--lav); border-radius:999px; padding:.05rem .55rem; font-size:.7rem; font-weight:700; margin-left:.3rem; }
.pv-empty { background:#fff; border:1px dashed #D9CCE0; border-radius:18px; padding:1rem; color:var(--muted); text-align:center; }

@media (max-width: 900px) {
  .block-container { padding:1rem !important; border-radius:20px; }
  .pv-hero { font-size:2.6rem; } .pv-illus { display:none; } [class*="st-key-card_"] { min-height:0; }
}
</style>
"""

ILLUSTRATION = """
<svg viewBox="0 0 260 175" width="260" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
 <rect x="10" y="10" width="190" height="125" rx="14" fill="#E6DCFF"/>
 <path d="M10 24a14 14 0 0 1 14-14h162a14 14 0 0 1 14 14v14H10z" fill="#FFD6E6"/>
 <circle cx="26" cy="24" r="4" fill="#E84D91"/><circle cx="40" cy="24" r="4" fill="#fff"/><circle cx="54" cy="24" r="4" fill="#fff"/>
 <rect x="32" y="58" width="70" height="8" rx="4" fill="#2D2140"/><rect x="32" y="76" width="110" height="8" rx="4" fill="#E84D91"/>
 <rect x="32" y="94" width="60" height="8" rx="4" fill="#fff"/><rect x="32" y="112" width="100" height="8" rx="4" fill="#9B8DB0"/>
 <rect x="150" y="98" width="100" height="62" rx="14" fill="#C8F0E0"/>
 <path d="M178 130l14 14 28-30" stroke="#2D2140" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""


def apply() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def badge(status: str) -> str:
    label = "In Progress" if status == "Running" else status
    return f'<span class="pv-badge pv-{status}">{label}</span>'
