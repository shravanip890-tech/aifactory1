"""Thin HTTP client for the FastAPI backend. Raises ApiError with a readable message."""
import atexit
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
_proc: subprocess.Popen | None = None


class ApiError(Exception):
    pass


def base_url() -> str:
    return os.getenv("API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")


def _request(method: str, path: str, *, raw: bool = False, timeout: float = 30, **kw):
    try:
        r = httpx.request(method, base_url() + path, timeout=timeout, **kw)
    except httpx.HTTPError as exc:
        raise ApiError(f"Cannot reach the API at {base_url()} ({type(exc).__name__}). "
                       "Start it with: uvicorn backend.main:app --port 8000") from exc
    if r.status_code >= 400:
        try:
            err = r.json()["error"]
            msg = err["message"]
            if err.get("details"):
                msg += " " + "; ".join(f"{d['field']}: {d['message']}" for d in err["details"])
        except Exception:
            msg = f"HTTP {r.status_code}"
        raise ApiError(msg)
    return r.content if raw else r.json()["data"]


def health() -> bool:
    try:
        return _request("GET", "/health", timeout=3)["status"] == "ok"
    except ApiError:
        return False


def create_project(name, category, description="", features=None):
    return _request("POST", "/api/projects", json={"name": name, "category": category,
                                                   "description": description, "features": features or []})


def generate(project_id):
    return _request("POST", f"/api/projects/{project_id}/generate", timeout=300)


def list_projects(**params):
    return _request("GET", "/api/projects", params={k: v for k, v in params.items() if v not in (None, "", "All")})


def get_project(project_id):
    return _request("GET", f"/api/projects/{project_id}")


def download(project_id) -> bytes:
    return _request("GET", f"/api/projects/{project_id}/download", raw=True)


def delete(project_id):
    return _request("DELETE", f"/api/projects/{project_id}")


def analytics(include_demo=False):
    return _request("GET", "/api/analytics", params={"include_demo": include_demo})


def settings():
    return _request("GET", "/api/settings")


def stop_backend() -> None:
    global _proc
    if _proc and _proc.poll() is None:
        _proc.terminate()
    _proc = None


def ensure_backend() -> bool:
    """True if the API answers. If not, start it locally on a free port (unless AUTOSTART_BACKEND=false)."""
    global _proc
    if health():
        return True
    if os.getenv("AUTOSTART_BACKEND", "true").strip().lower() in {"0", "false", "no", "off"}:
        return False
    if _proc and _proc.poll() is None:  # already starting
        for _ in range(40):
            if health():
                return True
            time.sleep(0.25)
        return False
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    (ROOT / "data").mkdir(exist_ok=True)
    log = open(ROOT / "data" / "api.log", "ab")
    _proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "127.0.0.1",
                              "--port", str(port), "--log-level", "warning"], cwd=ROOT, stdout=log, stderr=log)
    atexit.register(stop_backend)
    os.environ["API_BASE_URL"] = f"http://127.0.0.1:{port}"
    for _ in range(60):
        if health():
            return True
        if _proc.poll() is not None:
            return False
        time.sleep(0.25)
    return False
