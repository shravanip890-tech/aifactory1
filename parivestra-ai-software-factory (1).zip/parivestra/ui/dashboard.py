"""All pages. Every number and list comes from the API; nothing is hardcoded."""
import html
from datetime import datetime

import streamlit as st

from . import api_client as api
from .styles import ILLUSTRATION, badge

PAGES = ["Home", "Generate Project", "My Projects", "Analytics", "Documentation", "Settings"]
FILTERS = ["All", "Billing", "GST", "Inventory", "CRM", "Custom"]
CARDS = [("Billing", "Billing Software", "Products, customers, invoices, totals and invoice history."),
         ("GST", "GST Invoice App", "Invoices with configurable tax rates and tax summaries."),
         ("Inventory", "Inventory Manager", "Products, stock levels, movement history and low-stock flags."),
         ("CRM", "Customer Management", "Customer records, contact details, notes and history."),
         ("Custom", "Custom Project", "A basic runnable starter from supported options.")]
CUSTOM_FEATURES = {"notes": "Notes on items", "csv_export": "CSV export of items"}


def go(page: str, category: str | None = None) -> None:
    st.session_state["page"] = page
    if category:
        st.session_state["prefill_category"] = category


def call(fn, *args, **kw):
    """Run an API call; show a clear error and return None on failure."""
    try:
        return fn(*args, **kw)
    except api.ApiError as exc:
        st.error(str(exc))
        return None


def demo_flag() -> bool:
    return bool(st.session_state.get("show_demo", False))


ICONS = {"Billing": "▤", "GST": "%", "Inventory": "▣", "CRM": "☺", "Custom": "✦"}
NAV_ICONS = {"Home": "home", "Generate Project": "add_circle", "My Projects": "folder", "Analytics": "bar_chart",
             "Documentation": "article", "Settings": "settings"}


def created_label(iso: str) -> str:
    return datetime.fromisoformat(iso).strftime("%d %b %Y")


def progress(p: dict) -> tuple[int, str]:
    """Progress comes from real results only."""
    if p["status"] == "Completed":
        return 100, "100% complete"
    if p["status"] == "Failed":
        done = sum(c["status"] == "passed" for c in p["checks"])
        return (int(done / len(p["checks"]) * 100) if p["checks"] else 0), f"Failed - {done} of {len(p['checks'])} checks passed"
    if p["status"] == "Running":
        return 0, "Running..."
    return 0, "Not generated yet"


def home() -> None:
    main, side = st.columns([3.1, 1.45], gap="large")
    with main:
        left, right = st.columns([2.6, 1.2])
        left.markdown('<div class="pv-hero">Build your<br>software</div>'
                      '<div class="pv-sub">Turn your idea into a working application</div>', unsafe_allow_html=True)
        right.markdown(f'<div class="pv-illus">{ILLUSTRATION}</div>', unsafe_allow_html=True)
        category = st.radio("Category", FILTERS, horizontal=True, label_visibility="collapsed", key="home_filter")
        query = st.text_input("Search", placeholder="Search templates or your projects...", label_visibility="collapsed",
                              key="home_search")
        st.markdown('<div class="pv-section">Popular Templates</div>', unsafe_allow_html=True)
        cards = [c for c in CARDS if (category == c[0] or (category == "All" and c[0] != "Custom") or
                                      (category == "All" and query)) and
                 (not query or query.lower() in (c[1] + c[2] + c[0]).lower())]
        if not cards:
            st.info("No templates match your filter or search.")
        for i in range(0, len(cards), 2):
            cols = st.columns(2)
            for col, (cat, title, desc) in zip(cols, cards[i:i + 2]):
                with col, st.container(key=f"card_{cat}"):
                    st.markdown(f'<div class="pv-top"><span class="pv-cat"><span class="pv-ico">{ICONS[cat]}</span>{cat}</span>'
                                f'<span class="pv-tag">Quick Start</span></div>'
                                f'<div class="pv-ct">{title}</div><div class="pv-cd">{desc}</div>', unsafe_allow_html=True)
                    st.button("Create Project", key=f"create_{cat}", on_click=go, args=("Generate Project", cat))
        if query:
            found = call(api.list_projects, search=query, category=category, include_demo=demo_flag())
            if found is not None:
                st.markdown('<div class="pv-section">Matching projects</div>', unsafe_allow_html=True)
                if not found:
                    st.info("No saved projects match your search.")
                for p in found[:5]:
                    st.markdown(f"**{html.escape(p['name'])}** - {p['category']} - {badge(p['status'])}", unsafe_allow_html=True)
    with side:
        overview()


def overview() -> None:
    show_demo = demo_flag()
    with st.container(key="overview"):
        data = call(api.analytics, show_demo)
        projects = call(api.list_projects, include_demo=show_demo)
        if data is None or projects is None:
            return
        s = data["by_status"]
        pending = s["Queued"] + s["Running"]
        inc = '<span class="pv-inc">Includes demo</span>' if show_demo else ""
        st.markdown(
            '<div class="pv-wel"><div><b>Welcome back, Guest</b><br><small>Ready to build something?</small></div>'
            '<span class="pv-avatar">G</span></div>'
            f'<div class="pv-h">Project Overview {inc}</div>'
            f'<div class="pv-tiles"><div class="pv-tile" style="background:var(--lav)"><b>{data["total_projects"]}</b><small>Total</small></div>'
            f'<div class="pv-tile" style="background:var(--green)"><b>{s["Completed"]}</b><small>Completed</small></div>'
            f'<div class="pv-tile" style="background:var(--pink)"><b>{pending}</b><small>Pending</small></div></div>',
            unsafe_allow_html=True)
        week = data["weekly_activity"]
        peak = max([w["real"] + w["demo"] for w in week] + [1])
        bars, days = "", ""
        for w in week:
            total = w["real"] + w["demo"]
            if total == 0:
                inner = '<div class="z"></div>'
            else:
                inner = (f'<div class="d" style="height:{w["demo"] / peak * 100}%"></div>' if w["demo"] else "") + \
                        (f'<div class="r" style="height:{w["real"] / peak * 100}%"></div>' if w["real"] else "")
            bars += f'<div class="pv-bar" title="{w["day"]}: {total}">{inner}</div>'
            days += f'<span>{w["label"]}</span>'
        note = "Lavender is demo data. Rose is your real runs." if show_demo else "Rose is your real runs (projects created per day)."
        st.markdown(f'<div class="pv-h">Weekly activity</div><div class="pv-bars">{bars}</div><div class="pv-days">{days}</div>'
                    f'<div class="pv-note">{note}</div><div class="pv-h">My Projects</div>', unsafe_allow_html=True)
        if not projects:
            st.markdown('<div class="pv-empty">No projects yet. Pick a template and click Create Project.</div>', unsafe_allow_html=True)
        for p in projects[:4]:
            pct, label = progress(p)
            demo = '<span class="pv-demo">Demo</span>' if p["is_demo"] else ""
            st.markdown(
                f'<div class="pv-proj"><div class="t"><span>{html.escape(p["name"])}{demo}</span>{badge(p["status"])}</div>'
                f'<small>Created {created_label(p["created_at"])}</small>'
                f'<div class="pv-bg"><i style="width:{pct}%"></i></div><small>{label}</small></div>', unsafe_allow_html=True)
        if len(projects) > 4:
            st.caption(f"+{len(projects) - 4} more in My Projects")
        st.checkbox("Show demo data", key="show_demo")


def render_result(p: dict) -> None:
    st.markdown(f"{badge(p['status'])} &nbsp; **{html.escape(p['name'])}**", unsafe_allow_html=True)
    if p["status"] == "Failed":
        st.error(p["error"] or "Generation failed.")
    for c in p["checks"]:
        icon = {"passed": "✅", "failed": "❌", "skipped": "⏭️"}.get(c["status"], "•")
        st.write(f"{icon} **{c['name']}** ({c['status']}): {c['detail']}")
    if p.get("files"):
        with st.expander(f"{len(p['files'])} generated files"):
            for f in p["files"]:
                st.code(f"{f['path']}  ({f['size']} bytes)", language=None)


def generate_page() -> None:
    st.markdown("## Generate Project")
    cats = FILTERS[1:]
    default = st.session_state.pop("prefill_category", None)
    if default in cats:
        st.session_state["gen_category"] = default
    with st.form("generate_form"):
        name = st.text_input("Project name", placeholder="My Shop Billing", help="3-60 characters; letters, digits, spaces, - and _")
        category = st.selectbox("Template", cats, key="gen_category")
        description = st.text_area("Description (optional)", max_chars=1000)
        feats = st.multiselect("Custom options (Custom template only)", list(CUSTOM_FEATURES), format_func=CUSTOM_FEATURES.get)
        extra = st.text_input("Other requested features, comma-separated (Custom only)",
                              help="Unsupported requests are listed in NOT_IMPLEMENTED.md, not built.")
        submitted = st.form_submit_button("Generate Project")
    if category != "Custom":
        st.caption("Selectable options apply to the Custom template only; other templates use their fixed feature set.")
    if submitted:
        features = feats + [x.strip() for x in extra.split(",") if x.strip()] if category == "Custom" else []
        project = call(api.create_project, name, category, description, features)
        if project:
            with st.spinner("Generating and verifying files…"):
                result = call(api.generate, project["id"])
            if result:
                st.session_state["last_result"] = result
    result = st.session_state.get("last_result")
    if result:
        render_result(result)
        if result["status"] == "Completed":
            zip_bytes = call(api.download, result["id"])
            if zip_bytes:
                st.download_button("Download ZIP", zip_bytes, file_name=f"{result['slug']}.zip", mime="application/zip")


def projects_page() -> None:
    st.markdown("## My Projects")
    c1, c2, c3 = st.columns([2, 1, 1])
    query = c1.text_input("Search", placeholder="Search by name or description", label_visibility="collapsed")
    status = c2.selectbox("Status", ["All", "Queued", "Running", "Completed", "Failed"], label_visibility="collapsed")
    c3.checkbox("Show demo data", key="show_demo")
    projects = call(api.list_projects, search=query, status=status, include_demo=demo_flag())
    if projects is None:
        return
    if not projects:
        st.info("No projects found. Use Generate Project to create your first one.")
    for p in projects:
        with st.container(border=True):
            demo = '<span class="pv-demo">DEMO DATA</span>' if p["is_demo"] else ""
            st.markdown(f"**{html.escape(p['name'])}** {demo} · {p['category']} · {badge(p['status'])}<br>"
                        f"<small>{p['file_count']} files · created {p['created_at'][:16].replace('T', ' ')}</small>",
                        unsafe_allow_html=True)
            if p["error"]:
                st.error(p["error"])
            b1, b2, b3, b4 = st.columns(4)
            if b1.button("Regenerate" if p["status"] in ("Completed", "Failed") else "Generate", key=f"g_{p['id']}"):
                with st.spinner("Generating…"):
                    r = call(api.generate, p["id"])
                if r:
                    st.session_state["last_result"] = r
                    st.rerun()
            if p["status"] == "Completed":
                if b2.button("Prepare ZIP", key=f"z_{p['id']}"):
                    st.session_state[f"zip_{p['id']}"] = call(api.download, p["id"])
                if st.session_state.get(f"zip_{p['id']}"):
                    b3.download_button("Download", st.session_state[f"zip_{p['id']}"], file_name=f"{p['slug']}.zip",
                                       mime="application/zip", key=f"d_{p['id']}")
            if b4.button("Delete", key=f"x_{p['id']}"):
                st.session_state[f"confirm_{p['id']}"] = True
            if st.session_state.get(f"confirm_{p['id']}"):
                st.warning("Delete this project and its generated files?")
                if st.button("Yes, delete", key=f"y_{p['id']}") and call(api.delete, p["id"]):
                    st.session_state.pop(f"confirm_{p['id']}", None)
                    st.rerun()


def analytics_page() -> None:
    st.markdown("## Analytics")
    st.checkbox("Include demo data", key="show_demo")
    d = call(api.analytics, demo_flag())
    if d is None:
        return
    if not d["total_projects"]:
        st.info("No data yet. Analytics appear after you create projects.")
        return
    m = st.columns(4)
    m[0].metric("Projects", d["total_projects"])
    m[1].metric("Success rate", "n/a" if d["success_rate"] is None else f"{d['success_rate']}%")
    m[2].metric("Files generated", d["total_files_generated"])
    m[3].metric("Avg generation", "n/a" if d["avg_generation_ms"] is None else f"{d['avg_generation_ms']} ms")
    a, b = st.columns(2)
    a.markdown("**By status**"); a.bar_chart(d["by_status"], color="#E84D91")
    b.markdown("**By category**"); b.bar_chart(d["by_category"], color="#9B7FD1")
    if d["demo_projects_total"] and not d["includes_demo"]:
        st.caption(f"{d['demo_projects_total']} demo projects exist and are excluded from these numbers.")


DOCS = """
## Documentation
**What this does.** Choose a template, click *Generate Project*, and the backend writes a real FastAPI + SQLite starter
into the generation directory, verifies it, and records the result. A project is **Completed** only if every required
step passed.

**Statuses.** Queued (saved, not generated) · Running · Completed · Failed (see the error and the checks list).

**Checks.** Required files exist, no empty files, all Python files compile, placeholders resolved. The generated
project's own tests run only if `RUN_GENERATED_TESTS=true` on the server; otherwise that check is shown as *skipped*.

**Templates.** Billing, GST Invoice, Inventory, Customer Management, and a basic Custom starter. These are starters
(REST API, no UI or login), not finished products. Custom requests outside the supported options are listed in
`NOT_IMPLEMENTED.md` in the generated project.

**GST.** The GST template does arithmetic with configurable rates. Correct GST treatment depends on the transaction and
applicable Indian tax rules; it is not verified for compliance. Get professional review.

**API.** Interactive docs are served by the backend at `/docs`.

**Not implemented.** Authentication, payments/subscriptions, external AI-provider integration, cloud deployment.
"""


def docs_page() -> None:
    st.markdown(DOCS)
    st.link_button("Open API docs", api.base_url() + "/docs")


def settings_page() -> None:
    st.markdown("## Settings")
    s = call(api.settings)
    if s is None:
        return
    st.markdown("**Server configuration** (read-only; change via environment variables / `.env`, then restart the API)")
    st.json({k: v for k, v in s.items() if k != "integrations"})
    st.markdown("**Optional integrations**")
    for k, v in s["integrations"].items():
        st.write(f"- {k.replace('_', ' ').title()}: *{v}*")
    st.caption(f"Dashboard API address: {api.base_url()} (set API_BASE_URL)")
    st.checkbox("Show demo data in lists and analytics", key="show_demo")
    st.caption("Demo data is created only by running `python -m backend.seed`.")
