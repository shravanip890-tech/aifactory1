"""__PROJECT_NAME__ - inventory starter (FastAPI + SQLite)."""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="__PROJECT_NAME__")

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0, reorder_level INTEGER NOT NULL DEFAULT 5);
CREATE TABLE IF NOT EXISTS movements (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
    change INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
"""


@contextmanager
def db():
    conn = sqlite3.connect(os.getenv("APP_DB", "app.db"))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


class ProductIn(BaseModel):
    sku: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=120)
    quantity: int = Field(0, ge=0)
    reorder_level: int = Field(5, ge=0)


class MovementIn(BaseModel):
    change: int
    reason: str = Field(min_length=1, max_length=200)


def present(row) -> dict:
    d = dict(row)
    d["low_stock"] = d["quantity"] <= d["reorder_level"]
    return d


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/products", status_code=201)
def add_product(p: ProductIn):
    with db() as c:
        try:
            cur = c.execute("INSERT INTO products (sku,name,quantity,reorder_level) VALUES (?,?,?,?)",
                            (p.sku, p.name, p.quantity, p.reorder_level))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "SKU already exists")
        if p.quantity:
            c.execute("INSERT INTO movements (product_id,change,reason,created_at) VALUES (?,?,?,?)",
                      (cur.lastrowid, p.quantity, "Opening stock", now()))
        return present(c.execute("SELECT * FROM products WHERE id=?", (cur.lastrowid,)).fetchone())


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@app.get("/products")
def list_products():
    with db() as c:
        return [present(r) for r in c.execute("SELECT * FROM products ORDER BY id")]


@app.get("/low-stock")
def low_stock():
    with db() as c:
        return [present(r) for r in c.execute("SELECT * FROM products WHERE quantity <= reorder_level ORDER BY quantity")]


@app.post("/products/{product_id}/movements", status_code=201)
def add_movement(product_id: int, m: MovementIn):
    if m.change == 0:
        raise HTTPException(422, "Change must be non-zero")
    with db() as c:
        row = c.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Product not found")
        if row["quantity"] + m.change < 0:
            raise HTTPException(409, "Insufficient stock")
        c.execute("UPDATE products SET quantity = quantity + ? WHERE id=?", (m.change, product_id))
        c.execute("INSERT INTO movements (product_id,change,reason,created_at) VALUES (?,?,?,?)",
                  (product_id, m.change, m.reason, now()))
        return present(c.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone())


@app.get("/products/{product_id}/movements")
def movement_history(product_id: int):
    with db() as c:
        if not c.execute("SELECT 1 FROM products WHERE id=?", (product_id,)).fetchone():
            raise HTTPException(404, "Product not found")
        return [dict(r) for r in c.execute("SELECT * FROM movements WHERE product_id=? ORDER BY id", (product_id,))]
