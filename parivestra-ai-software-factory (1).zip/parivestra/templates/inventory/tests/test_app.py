import os
import tempfile

os.environ["APP_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)


def test_stock_flow_and_low_stock():
    p = client.post("/products", json={"sku": "S1", "name": "Widget", "quantity": 10, "reorder_level": 4}).json()
    assert p["low_stock"] is False
    r = client.post(f"/products/{p['id']}/movements", json={"change": -7, "reason": "Sale"})
    assert r.json()["quantity"] == 3 and r.json()["low_stock"] is True
    assert [x["sku"] for x in client.get("/low-stock").json()] == ["S1"]
    assert [m["change"] for m in client.get(f"/products/{p['id']}/movements").json()] == [10, -7]


def test_rejections():
    p = client.post("/products", json={"sku": "S2", "name": "Bolt", "quantity": 1}).json()
    assert client.post(f"/products/{p['id']}/movements", json={"change": -5, "reason": "x"}).status_code == 409
    assert client.post("/products", json={"sku": "S2", "name": "Dup"}).status_code == 409
    assert client.post("/products/999/movements", json={"change": 1, "reason": "x"}).status_code == 404
