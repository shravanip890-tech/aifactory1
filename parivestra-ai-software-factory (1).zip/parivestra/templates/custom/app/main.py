"""__PROJECT_NAME__ - custom starter (FastAPI + SQLite). Options: __FEATURES__"""
import os
import sqlite3
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="__PROJECT_NAME__")

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, details TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL, text TEXT NOT NULL);
"""


@contextmanager
def db():
    conn = sqlite3.connect(os.getenv("APP_DB", "app.db"))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


class ItemIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    details: str = Field("", max_length=2000)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/items", status_code=201)
def add_item(i: ItemIn):
    with db() as c:
        cur = c.execute("INSERT INTO items (title, details) VALUES (?, ?)", (i.title, i.details))
        return {"id": cur.lastrowid, **i.model_dump()}


@app.get("/items")
def list_items():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM items ORDER BY id")]


@app.get("/items/{item_id}")
def get_item(item_id: int):
    with db() as c:
        row = c.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Item not found")
        return dict(row)


# __OPTIONAL_ROUTERS__
