import csv
import io

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse

from .main import db

router = APIRouter()


@router.get("/items.csv", response_class=PlainTextResponse)
def export_items():
    with db() as c:
        rows = c.execute("SELECT id, title, details FROM items ORDER BY id").fetchall()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "title", "details"])
    for r in rows:
        w.writerow([r["id"], r["title"], r["details"]])
    return buf.getvalue()
