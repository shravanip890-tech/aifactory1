from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .main import db

router = APIRouter()


class NoteIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


@router.post("/items/{item_id}/notes", status_code=201)
def add_note(item_id: int, n: NoteIn):
    with db() as c:
        if not c.execute("SELECT 1 FROM items WHERE id=?", (item_id,)).fetchone():
            raise HTTPException(404, "Item not found")
        cur = c.execute("INSERT INTO notes (item_id, text) VALUES (?, ?)", (item_id, n.text))
        return {"id": cur.lastrowid, "item_id": item_id, "text": n.text}


@router.get("/items/{item_id}/notes")
def list_notes(item_id: int):
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM notes WHERE item_id=? ORDER BY id", (item_id,))]
