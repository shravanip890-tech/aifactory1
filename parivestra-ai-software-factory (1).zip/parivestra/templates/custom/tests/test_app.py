import os
import tempfile

os.environ["APP_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)


def test_items_crud():
    r = client.post("/items", json={"title": "First", "details": "hello"})
    assert r.status_code == 201
    assert client.get(f"/items/{r.json()['id']}").json()["title"] == "First"
    assert len(client.get("/items").json()) == 1
    assert client.get("/items/999").status_code == 404
    assert client.post("/items", json={"title": ""}).status_code == 422


def _has(path):
    return any(getattr(r, "path", None) == path for r in app.routes)


def test_optional_modules_only_when_selected():
    item = client.post("/items", json={"title": "N"}).json()
    if _has("/items/{item_id}/notes"):
        assert client.post(f"/items/{item['id']}/notes", json={"text": "hi"}).status_code == 201
        assert client.get(f"/items/{item['id']}/notes").json()[0]["text"] == "hi"
    if _has("/items.csv"):
        assert client.get("/items.csv").text.startswith("id,title,details")
