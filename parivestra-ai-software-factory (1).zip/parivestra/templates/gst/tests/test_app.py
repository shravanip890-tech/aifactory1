import os
import tempfile

os.environ["APP_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)


def test_tax_math_and_summary():
    r = client.post("/invoices", json={"customer_name": "Acme", "intra_state": True, "items": [
        {"description": "A", "quantity": 2, "unit_price": "100.00", "tax_rate": "18"},
        {"description": "B", "quantity": 1, "unit_price": "50.00", "tax_rate": "5"}]})
    assert r.status_code == 201
    d = r.json()
    assert d["taxable_total"] == "250.00" and d["tax_total"] == "38.50" and d["grand_total"] == "288.50"
    assert d["tax_split"] == {"cgst": "19.25", "sgst": "19.25"}
    assert [s["rate"] for s in d["tax_summary"]] == ["5", "18"]
    assert client.get(f"/invoices/{d['id']}").json()["grand_total"] == "288.50"
    assert len(client.get("/invoices").json()) == 1


def test_inter_state_and_rejected_rate():
    ok = client.post("/invoices", json={"customer_name": "X", "intra_state": False,
                                        "items": [{"description": "A", "quantity": 1, "unit_price": "100", "tax_rate": "12"}]})
    assert ok.json()["tax_split"] == {"igst": "12.00"}
    bad = client.post("/invoices", json={"customer_name": "X", "items": [
        {"description": "A", "quantity": 1, "unit_price": "100", "tax_rate": "7"}]})
    assert bad.status_code == 422
