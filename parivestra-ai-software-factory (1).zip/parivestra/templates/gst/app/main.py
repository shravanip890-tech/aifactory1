"""__PROJECT_NAME__ - GST invoice starter (FastAPI + SQLite).

Arithmetic only. NOT verified for GST compliance; see README.
"""
import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import ROUND_HALF_UP, Decimal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="__PROJECT_NAME__")

SCHEMA = """
CREATE TABLE IF NOT EXISTS invoices (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL,
    intra_state INTEGER NOT NULL, created_at TEXT NOT NULL, body TEXT NOT NULL);
"""


def allowed_rates() -> list[Decimal]:
    raw = os.getenv("GST_ALLOWED_RATES", "0,5,12,18,28")
    return [Decimal(x.strip()) for x in raw.split(",") if x.strip()]


@contextmanager
def db():
    conn = sqlite3.connect(os.getenv("APP_DB", "app.db"))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def money(x: Decimal) -> Decimal:
    return x.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


class LineIn(BaseModel):
    description: str = Field(min_length=1, max_length=200)
    quantity: int = Field(gt=0)
    unit_price: Decimal = Field(ge=0)
    tax_rate: Decimal


class InvoiceIn(BaseModel):
    customer_name: str = Field(min_length=1, max_length=120)
    intra_state: bool = True
    items: list[LineIn] = Field(min_length=1)


def compute(inv: InvoiceIn) -> dict:
    rates = allowed_rates()
    lines, summary = [], {}
    for ln in inv.items:
        if ln.tax_rate not in rates:
            raise HTTPException(422, f"Tax rate {ln.tax_rate} not allowed. Allowed: {[str(r) for r in rates]}")
        taxable = money(ln.unit_price * ln.quantity)
        tax = money(taxable * ln.tax_rate / 100)
        lines.append({"description": ln.description, "quantity": ln.quantity, "unit_price": str(ln.unit_price),
                      "tax_rate": str(ln.tax_rate), "taxable_amount": str(taxable), "tax_amount": str(tax),
                      "line_total": str(taxable + tax)})
        s = summary.setdefault(str(ln.tax_rate), {"taxable": Decimal(0), "tax": Decimal(0)})
        s["taxable"] += taxable
        s["tax"] += tax
    taxable_total = sum((Decimal(x["taxable_amount"]) for x in lines), Decimal(0))
    tax_total = sum((Decimal(x["tax_amount"]) for x in lines), Decimal(0))
    split = ({"cgst": str(money(tax_total / 2)), "sgst": str(tax_total - money(tax_total / 2))} if inv.intra_state
             else {"igst": str(tax_total)})
    return {"customer_name": inv.customer_name, "intra_state": inv.intra_state, "items": lines,
            "tax_summary": [{"rate": r, "taxable": str(v["taxable"]), "tax": str(v["tax"])} for r, v in sorted(summary.items(), key=lambda kv: Decimal(kv[0]))],
            "taxable_total": str(taxable_total), "tax_total": str(tax_total), "tax_split": split,
            "grand_total": str(taxable_total + tax_total),
            "disclaimer": "Arithmetic only; not verified for GST compliance."}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/tax-rates")
def tax_rates():
    return {"allowed_rates": [str(r) for r in allowed_rates()]}


@app.post("/invoices", status_code=201)
def create_invoice(inv: InvoiceIn):
    result = compute(inv)
    with db() as c:
        cur = c.execute("INSERT INTO invoices (customer_name, intra_state, created_at, body) VALUES (?,?,?,?)",
                        (inv.customer_name, int(inv.intra_state), datetime.now(timezone.utc).isoformat(timespec="seconds"),
                         json.dumps(result)))
        return {"id": cur.lastrowid, **result}


@app.get("/invoices")
def list_invoices():
    with db() as c:
        return [{"id": r["id"], "customer_name": r["customer_name"], "created_at": r["created_at"],
                 "grand_total": json.loads(r["body"])["grand_total"]} for r in c.execute("SELECT * FROM invoices ORDER BY id DESC")]


@app.get("/invoices/{invoice_id}")
def get_invoice(invoice_id: int):
    with db() as c:
        row = c.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Invoice not found")
        return {"id": row["id"], "created_at": row["created_at"], **json.loads(row["body"])}
