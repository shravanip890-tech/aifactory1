"""__PROJECT_NAME__ - billing starter (FastAPI + SQLite)."""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="__PROJECT_NAME__")

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL);
CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT);
CREATE TABLE IF NOT EXISTS invoices (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL,
    created_at TEXT NOT NULL, subtotal REAL NOT NULL, total REAL NOT NULL);
CREATE TABLE IF NOT EXISTS invoice_items (invoice_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
    name TEXT NOT NULL, unit_price REAL NOT NULL, quantity INTEGER NOT NULL, line_total REAL NOT NULL);
"""


@contextmanager
def db():
    conn = sqlite3.connect(os.getenv("APP_DB", "app.db"))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


class ProductIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    price: float = Field(ge=0)


class CustomerIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: str | None = None


class LineIn(BaseModel):
    product_id: int
    quantity: int = Field(gt=0)


class InvoiceIn(BaseModel):
    customer_id: int
    items: list[LineIn] = Field(min_length=1)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/products", status_code=201)
def add_product(p: ProductIn):
    with db() as c:
        cur = c.execute("INSERT INTO products (name, price) VALUES (?, ?)", (p.name, p.price))
        return {"id": cur.lastrowid, **p.model_dump()}


@app.get("/products")
def list_products():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM products ORDER BY id")]


@app.post("/customers", status_code=201)
def add_customer(cu: CustomerIn):
    with db() as c:
        cur = c.execute("INSERT INTO customers (name, email) VALUES (?, ?)", (cu.name, cu.email))
        return {"id": cur.lastrowid, **cu.model_dump()}


@app.get("/customers")
def list_customers():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM customers ORDER BY id")]


@app.post("/invoices", status_code=201)
def create_invoice(inv: InvoiceIn):
    with db() as c:
        if not c.execute("SELECT 1 FROM customers WHERE id=?", (inv.customer_id,)).fetchone():
            raise HTTPException(404, "Customer not found")
        lines, subtotal = [], 0.0
        for item in inv.items:
            prod = c.execute("SELECT * FROM products WHERE id=?", (item.product_id,)).fetchone()
            if not prod:
                raise HTTPException(404, f"Product {item.product_id} not found")
            line_total = round(prod["price"] * item.quantity, 2)
            subtotal += line_total
            lines.append((prod["id"], prod["name"], prod["price"], item.quantity, line_total))
        subtotal = round(subtotal, 2)
        cur = c.execute("INSERT INTO invoices (customer_id, created_at, subtotal, total) VALUES (?,?,?,?)",
                        (inv.customer_id, datetime.now(timezone.utc).isoformat(timespec="seconds"), subtotal, subtotal))
        for ln in lines:
            c.execute("INSERT INTO invoice_items VALUES (?,?,?,?,?,?)", (cur.lastrowid, *ln))
        return get_invoice_row(c, cur.lastrowid)


def get_invoice_row(c, invoice_id: int):
    row = c.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Invoice not found")
    items = [dict(r) for r in c.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (invoice_id,))]
    return {**dict(row), "items": items}


@app.get("/invoices")
def invoice_history():
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM invoices ORDER BY id DESC")]


@app.get("/invoices/{invoice_id}")
def get_invoice(invoice_id: int):
    with db() as c:
        return get_invoice_row(c, invoice_id)
