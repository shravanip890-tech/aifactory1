import os
import tempfile

os.environ["APP_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)


def test_invoice_totals_and_history():
    p1 = client.post("/products", json={"name": "Pen", "price": 10.5}).json()
    p2 = client.post("/products", json={"name": "Book", "price": 100}).json()
    cust = client.post("/customers", json={"name": "Asha"}).json()
    r = client.post("/invoices", json={"customer_id": cust["id"], "items": [
        {"product_id": p1["id"], "quantity": 2}, {"product_id": p2["id"], "quantity": 1}]})
    assert r.status_code == 201
    assert r.json()["subtotal"] == 121.0 and r.json()["total"] == 121.0
    assert len(client.get("/invoices").json()) == 1
    assert len(client.get(f"/invoices/{r.json()['id']}").json()["items"]) == 2


def test_invalid_invoice():
    assert client.post("/invoices", json={"customer_id": 999, "items": [{"product_id": 1, "quantity": 1}]}).status_code == 404
    assert client.post("/invoices", json={"customer_id": 1, "items": []}).status_code == 422
