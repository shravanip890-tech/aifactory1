"""__PROJECT_NAME__ - customer management starter (FastAPI + SQLite)."""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="__PROJECT_NAME__")

SCHEMA = """
CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    email TEXT, phone TEXT, company TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL,
    text TEXT NOT NULL, created_at TEXT NOT NULL);
"""


@contextmanager
def db():
    conn = sqlite3.connect(os.getenv("APP_DB", "app.db"))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class CustomerIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: str | None = Field(None, max_length=200)
    phone: str | None = Field(None, max_length=40)
    company: str | None = Field(None, max_length=120)


class NoteIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/customers", status_code=201)
def add_customer(cu: CustomerIn):
    with db() as c:
        cur = c.execute("INSERT INTO customers (name,email,phone,company,created_at) VALUES (?,?,?,?,?)",
                        (cu.name, cu.email, cu.phone, cu.company, now()))
        return dict(c.execute("SELECT * FROM customers WHERE id=?", (cur.lastrowid,)).fetchone())


@app.get("/customers")
def list_customers(q: str | None = None):
    with db() as c:
        if q:
            rows = c.execute("SELECT * FROM customers WHERE name LIKE ? OR email LIKE ? ORDER BY id", (f"%{q}%", f"%{q}%"))
        else:
            rows = c.execute("SELECT * FROM customers ORDER BY id")
        return [dict(r) for r in rows]


@app.get("/customers/{customer_id}")
def customer_history(customer_id: int):
    with db() as c:
        row = c.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Customer not found")
        notes = [dict(r) for r in c.execute("SELECT * FROM notes WHERE customer_id=? ORDER BY id DESC", (customer_id,))]
        return {**dict(row), "notes": notes}


@app.post("/customers/{customer_id}/notes", status_code=201)
def add_note(customer_id: int, n: NoteIn):
    with db() as c:
        if not c.execute("SELECT 1 FROM customers WHERE id=?", (customer_id,)).fetchone():
            raise HTTPException(404, "Customer not found")
        cur = c.execute("INSERT INTO notes (customer_id,text,created_at) VALUES (?,?,?)", (customer_id, n.text, now()))
        return dict(c.execute("SELECT * FROM notes WHERE id=?", (cur.lastrowid,)).fetchone())
