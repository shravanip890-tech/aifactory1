import os
import tempfile

os.environ["APP_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)


def test_customer_notes_history_and_search():
    c = client.post("/customers", json={"name": "Ravi", "email": "ravi@example.com", "phone": "555"}).json()
    client.post(f"/customers/{c['id']}/notes", json={"text": "Called about renewal"})
    client.post(f"/customers/{c['id']}/notes", json={"text": "Sent quote"})
    hist = client.get(f"/customers/{c['id']}").json()
    assert [n["text"] for n in hist["notes"]] == ["Sent quote", "Called about renewal"]
    assert len(client.get("/customers", params={"q": "rav"}).json()) == 1
    assert client.get("/customers", params={"q": "zzz"}).json() == []


def test_not_found_and_validation():
    assert client.get("/customers/999").status_code == 404
    assert client.post("/customers/999/notes", json={"text": "x"}).status_code == 404
    assert client.post("/customers", json={"name": ""}).status_code == 422
