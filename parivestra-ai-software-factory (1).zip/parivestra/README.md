# Parivestra AI Software Factory

Generates **real, runnable starter projects** (FastAPI + SQLite) from templates, verifies the files, records honest
results in SQLite, and lets you download each project as a ZIP. A Streamlit dashboard (pastel mint / blush / lavender /
peach theme) sits on top of a FastAPI backend.

## What is real and what is not
- Real: project records in SQLite, files written to disk, file verification (required files, non-empty, Python syntax,
  placeholders), ZIP download, analytics computed from stored data, 37 automated tests.
- Statuses: `Queued`, `Running`, `Completed`, `Failed`. `Completed` only when every required step passed.
- The generated project's own tests run only when `RUN_GENERATED_TESTS=true`; otherwise that check shows `skipped`.
  This is a plain subprocess with a timeout, **not a sandbox**.
- Templates are **starters** (REST API only: no UI, login or deployment). The Custom template supports `items`,
  `notes`, `csv_export`; anything else requested is listed in `NOT_IMPLEMENTED.md` inside the generated project.
- GST template: arithmetic with configurable rates. Not verified for GST/legal compliance; get professional review.
- **Not implemented:** authentication, payments/subscriptions, external AI-provider integration, cloud deployment,
  a marketing landing page.

## Install
```bash
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env   # optional; env vars can also be exported directly
```

## Run
From the folder that contains `app.py` and `backend/` (with the venv active):
```bash
streamlit run app.py
```
That is all: the dashboard starts the API itself on a free local port (log: `data/api.log`) and stops it when
Streamlit exits. API docs are then at `<that address>/docs`; the address is shown on the Settings page.

To run the API yourself instead (fixed port, e.g. for the docs page or other clients):
```bash
uvicorn backend.main:app --port 8000
set API_BASE_URL=http://127.0.0.1:8000     # PowerShell: $env:API_BASE_URL="http://127.0.0.1:8000"
streamlit run app.py
```
Set `AUTOSTART_BACKEND=false` to disable the automatic start.

Optional demo data (flagged `Demo`, left `Queued`, hidden by default; tick "Show demo data" to see it):
```bash
python -m backend.seed
```

## API
`GET /health` · `POST /api/projects` · `GET /api/projects` · `GET /api/projects/{id}` ·
`POST /api/projects/{id}/generate` · `GET /api/projects/{id}/download` · `DELETE /api/projects/{id}` ·
`GET /api/analytics` · also `GET /api/templates`, `GET /api/settings`.
All JSON responses use `{"success", "data", "error"}`.

## Test
```bash
pytest
```

## Security notes
Project names are validated; output dirs are `<12-hex-id>-<slug>` resolved inside `GENERATION_DIR`; deletion and ZIP
building refuse paths outside it; request bodies are size-limited; server paths and stack traces are not returned.
Generated code is never executed unless you enable `RUN_GENERATED_TESTS`.

## Troubleshooting
- *Dashboard says API not reachable*: check `data/api.log` for the reason (often a missing `pip install -r requirements.txt`).
- *Generated project missing on download (409)*: the folder was removed from disk; click Regenerate.
- *Project stuck in Running* (server killed mid-run): it cannot be regenerated until its status is reset in the DB.
- *Tests fail to import*: run `pip install -r requirements.txt` in the active environment.

## Layout
`app.py`, `ui/` (dashboard), `backend/` (`main.py`, `database.py`, `models.py`, `schemas.py`, `routers/`,
`services/orchestrator.py`, `services/generation_service.py`, `seed.py`), `templates/{billing,gst,inventory,crm,custom}`, `tests/`.
